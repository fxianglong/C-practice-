#include<iostream>
using namespace std;
int main()
{
	int x = 0; int R = 0;
	cin >> x;
	cin >> R; int out = 0;
	while (x)
	{
		out += 10 * (x%R);
		x = x / R;
	}
	cout << out << endl;
	return 0;
}