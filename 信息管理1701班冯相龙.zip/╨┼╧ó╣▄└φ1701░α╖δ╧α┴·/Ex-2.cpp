#include<iostream>
#include<vector>
using namespace std;
int main()
{
	int i = 0, j = 0;
	int N = 0; int x = 0;
	vector<int> str;
	while (cin >> x)
	{
		if (x != EOF)
			str.push_back(x);
	}
	cin >> N;
	for (i = 0; i < str.size();i++)
	for (j = i + 1; j < str.size(); j++)
	{
		if ((str[i] + str[j])==N)
	cout << "[" << i << "," <<j<<"]" << endl;
	}
	return 0;
}
