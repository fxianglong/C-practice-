#include<iostream>
using namespace std;
int main()
{
	int N = 0;
	while (cin >> N)
	{
		int count = 0; int i = 0;
		for (i = 0; i <= N; i++)
		{
			for (int j = 0; j <= N; j++)
			{
				if ((i + 2 * j) == N)
					count++;
			}
		}
		cout << count << endl;
	}
	return 0;
}
