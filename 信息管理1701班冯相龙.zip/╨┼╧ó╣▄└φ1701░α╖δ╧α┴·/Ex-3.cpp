#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<int> a;
	int arr[10000] = { 0 };
	int N = 0; int k = 0;
	cin >> N >> k;
	for (int i = 0; i < N; i++)
		cin >> arr[i];
	for (int i = 0; i < N; i++)
	{
		for (int j = i + 1; j < N; j++)
		{
			if (arr[i]>arr[j])
				swap(arr[i], arr[j]);
			else
			{
				a.push_back(arr[i]);
			}
		}
	}
	cout << a[k - 1] << endl;
	return 0;
}
