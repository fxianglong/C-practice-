#include<iostream>
#include<string>
using namespace std;
int sz(char s)
{
	if (s == 'I') return 1;
	if (s == 'V')return 5;
	if (s == 'X') return 10;
	if (s == 'L') return 50;
	if (s == 'C') return 100;
	if (s == 'D') return 500;
	if (s == 'M') return 1000;
}
int main()
{
	string s; char arr[10000] = { 0 };
	scanf("%s", arr); int sum = 0;
	for (int i = 0; i < strlen(arr); i++)
	{
		if (sz(arr[i]) < sz(arr[i + 1]))
			sum -= sz(arr[i]);
		else
		{
			sum += sz(arr[i]);
		}	
	}
	cout << sum << endl;
	return 0;
}